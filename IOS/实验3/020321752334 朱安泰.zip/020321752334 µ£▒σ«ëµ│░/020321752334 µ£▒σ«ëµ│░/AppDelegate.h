//
//  AppDelegate.h
//  020321752334 朱安泰
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

