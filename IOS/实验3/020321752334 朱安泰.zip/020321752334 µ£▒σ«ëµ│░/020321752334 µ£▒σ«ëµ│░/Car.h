//
//  Car.h
//  		
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject

 // 用于表示汽车名称的属性
@property(nonatomic,copy)NSString *name;
// 用于表示汽车图标路径的属性
@property(nonatomic,copy)NSString *icon;
+(instancetype)carWithDict:(NSDictionary *)dict;
-(instancetype)initWithDict:(NSDictionary *)dict;

@end
