//
//  ViewController.m
//  020321752334 朱安泰
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
