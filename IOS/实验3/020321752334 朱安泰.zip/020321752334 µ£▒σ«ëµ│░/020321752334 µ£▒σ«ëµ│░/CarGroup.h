//
//  CarGroup.h
//  		
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarGroup : NSObject

@end
