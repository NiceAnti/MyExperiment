//
//  main.m
//  020321752334 朱安泰
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
