//
//  Car.m
//  		
//
//  Created by Zhu Sanyuan on 20/10/12.
//  Copyright © 2020年 Zhu Sanyuan. All rights reserved.
//

#import "Car.h"

@implementation Car
+(instancetype)carWithDict:(NSDictionary *)dict{
  return [[self alloc]initWithDict:dict];
}
-(instancetype)initWithDict:(NSDictionary *)dict{
   if (self=[super init]) {
     [self setValuesForKeysWithDictionary:dict];
   }
   return self;
}

@end
